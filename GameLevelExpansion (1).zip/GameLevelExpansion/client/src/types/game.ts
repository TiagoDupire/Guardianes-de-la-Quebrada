export interface GameState {
  currentLevel: number;
  levelsCompleted: number[];
  totalScore: number;
  plantsLearned: number;
  level1: {
    completed: boolean;
    score: number;
    contaminantsRemaining: number;
  };
  level2: {
    completed: boolean;
    score: number;
    selectedTool: string | null;
    patches: { fertilized: boolean; planted: boolean }[];
    fertilizedCount: number;
    plantedCount: number;
    fertilizerCount: number;
  };
  level3: {
    completed: boolean;
    score: number;
    agua: number;
    sol: number;
    nutrientes: number;
    salud: number;
    temperatura: string;
    dia: number;
    diasSaludable: number;
    infusionesCreadas: number;
    puntuacion: number;
    mensajes: Array<{ text: string; type: string; day: number }>;
    gameOver: boolean;
  };
  level4: {
    completed: boolean;
    score: number;
    water: number;
    sun: number;
    nutrients: number;
    health: number;
    day: number;
    lastWatered: number;
    lastFertilized: number;
    gameOver: boolean;
    harvestScore: number;
    harvestStarted: boolean;
  };
  level5: {
    completed: boolean;
    score: number;
    currentQuestion: number;
    answered: boolean;
    gameFinished: boolean;
  };
}

export interface Contaminant {
  type: string;
  x: number;
  y: number;
  emoji: string;
}

export interface Question {
  question: string;
  options: string[];
  correct: number;
}
