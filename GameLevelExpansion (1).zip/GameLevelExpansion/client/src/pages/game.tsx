import { useState } from 'react';
import { useGameState } from '@/hooks/useGameState';
import MainMenu from '@/components/MainMenu';
import Level1 from '@/components/levels/Level1';
import Level2 from '@/components/levels/Level2.tsx';
import Level3 from '@/components/levels/Level3.tsx';
import Level4 from '@/components/levels/Level4.tsx';
import Level5 from '@/components/levels/Level5.tsx';

export default function GamePage() {
  const { gameState, updateGameState, updateLevelState, completeLevel, resetLevel, resetGame } = useGameState();
  const [currentScreen, setCurrentScreen] = useState<string>('main-menu');

  const goToMainMenu = () => {
    setCurrentScreen('main-menu');
  };

  const goToLevel = (levelNum: number) => {
    if (levelNum > 1 && !gameState.levelsCompleted.includes(levelNum - 1)) {
      return; // Level is locked
    }
    setCurrentScreen(`level${levelNum}`);
  };

  const handleLevelComplete = (levelNum: number) => {
    completeLevel(levelNum);
    goToMainMenu();
  };

  const renderCurrentScreen = () => {
    switch (currentScreen) {
      case 'main-menu':
        return (
          <MainMenu 
            gameState={gameState} 
            onLevelSelect={goToLevel}
            onResetGame={resetGame}
          />
        );
      case 'level1':
        return (
          <Level1 
            gameState={gameState.level1} 
            onComplete={() => handleLevelComplete(1)}
            onBack={goToMainMenu}
            onUpdateState={(updates: any) => updateLevelState('level1', updates)}
            onReset={() => resetLevel(1)}
          />
        );
      case 'level2':
        return (
          <Level2 
            gameState={gameState.level2} 
            onComplete={() => handleLevelComplete(2)}
            onBack={goToMainMenu}
            onUpdateState={(updates: any) => updateLevelState('level2', updates)}
            onReset={() => resetLevel(2)}
          />
        );
      case 'level3':
        return (
          <Level3 
            gameState={gameState.level3} 
            onComplete={() => handleLevelComplete(3)}
            onBack={goToMainMenu}
            onUpdateState={(updates: any) => updateLevelState('level3', updates)}
            onReset={() => resetLevel(3)}
          />
        );
      case 'level4':
        return (
          <Level4 
            gameState={gameState.level4} 
            onComplete={() => handleLevelComplete(4)}
            onBack={goToMainMenu}
            onUpdateState={(updates: any) => updateLevelState('level4', updates)}
            onReset={() => resetLevel(4)}
          />
        );
      case 'level5':
        return (
          <Level5 
            gameState={gameState.level5} 
            onComplete={() => handleLevelComplete(5)}
            onBack={goToMainMenu}
            onUpdateState={(updates: any) => updateLevelState('level5', updates)}
            onReset={() => resetLevel(5)}
          />
        );
      default:
        return <MainMenu gameState={gameState} onLevelSelect={goToLevel} onResetGame={resetGame} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-peru-green via-plant-green to-lime-400 flex items-center justify-center p-4 font-sans">
      <div className="w-full max-w-4xl bg-white/95 rounded-3xl shadow-2xl overflow-hidden">
        {renderCurrentScreen()}
      </div>
    </div>
  );
}
