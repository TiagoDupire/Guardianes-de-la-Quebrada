import { useState, useEffect } from 'react';
import { GameState } from '@/types/game';

const initialGameState: GameState = {
  currentLevel: 1,
  levelsCompleted: [],
  totalScore: 0,
  plantsLearned: 0,
  level1: { completed: false, score: 0, contaminantsRemaining: 10 },
  level2: { 
    completed: false, 
    score: 0, 
    selectedTool: null, 
    patches: Array(24).fill(null).map(() => ({ fertilized: false, planted: false })), 
    fertilizedCount: 0, 
    plantedCount: 0, 
    fertilizerCount: 15 
  },
  level3: { 
    completed: false, 
    score: 0, 
    agua: 45, 
    sol: 80, 
    nutrientes: 55, 
    salud: 100, 
    temperatura: 'fría', 
    dia: 1, 
    diasSaludable: 0, 
    infusionesCreadas: 0, 
    puntuacion: 0,
    mensajes: [], 
    gameOver: false 
  },
  level4: { 
    completed: false, 
    score: 0, 
    water: 50, 
    sun: 80, 
    nutrients: 60, 
    health: 70, 
    day: 1, 
    lastWatered: 0, 
    lastFertilized: 0, 
    gameOver: false, 
    harvestScore: 0,
    harvestStarted: false
  },
  level5: { 
    completed: false, 
    score: 0, 
    currentQuestion: 0, 
    answered: false, 
    gameFinished: false
  }
};

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>(initialGameState);

  // Load from localStorage on mount
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('plantas-medicinales-game-state');
        if (saved) {
          setGameState(prev => ({ ...prev, ...JSON.parse(saved) }));
        }
      } catch (error) {
        console.warn('Failed to load game state from localStorage:', error);
      }
    }
  }, []);

  // Save to localStorage whenever state changes
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('plantas-medicinales-game-state', JSON.stringify(gameState));
      } catch (error) {
        console.warn('Failed to save game state to localStorage:', error);
      }
    }
  }, [gameState]);

  const updateGameState = (updates: Partial<GameState>) => {
    setGameState(prev => ({ ...prev, ...updates }));
  };

  const updateLevelState = <T extends keyof GameState>(level: T, updates: Partial<GameState[T]>) => {
    setGameState(prev => {
      const currentLevel = prev[level];
      if (currentLevel && typeof currentLevel === 'object') {
        return {
          ...prev,
          [level]: { ...currentLevel, ...updates }
        };
      }
      return prev;
    });
  };

  const completeLevel = (levelNum: number) => {
    if (!gameState.levelsCompleted.includes(levelNum)) {
      const levelKey = `level${levelNum}` as keyof GameState;
      const levelData = gameState[levelKey];
      const levelScore = levelData && typeof levelData === 'object' && 'score' in levelData ? (levelData as any).score : 0;
      
      setGameState(prev => ({
        ...prev,
        levelsCompleted: [...prev.levelsCompleted, levelNum],
        plantsLearned: prev.plantsLearned + 1,
        totalScore: prev.totalScore + levelScore
      }));
    }
  };

  const resetGame = () => {
    setGameState(initialGameState);
  };

  const resetLevel = (levelNum: number) => {
    const levelKey = `level${levelNum}` as keyof GameState;
    const initialLevel = initialGameState[levelKey];
    if (initialLevel && typeof initialLevel === 'object') {
      setGameState(prev => ({
        ...prev,
        [levelKey]: { ...initialLevel }
      }));
    }
  };

  return {
    gameState,
    updateGameState,
    updateLevelState,
    completeLevel,
    resetGame,
    resetLevel
  };
};
