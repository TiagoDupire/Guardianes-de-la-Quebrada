import { useState, useEffect } from 'react';

interface Level2Props {
  gameState: any;
  onComplete: () => void;
  onBack: () => void;
  onUpdateState: (updates: any) => void;
  onReset: () => void;
}

export default function Level2({ gameState, onComplete, onBack, onUpdateState, onReset }: Level2Props) {
  const [message, setMessage] = useState<{ text: string; type: string } | null>(null);

  useEffect(() => {
    if (gameState.plantedCount >= 12 && !gameState.completed) {
      onUpdateState({ completed: true, score: 100 });
      showMessage('¡Felicidades! Has completado el nivel de Muña.', 'success');
      setTimeout(() => onComplete(), 2000);
    }
  }, [gameState.plantedCount, gameState.completed]);

  const selectTool = (tool: string) => {
    onUpdateState({ selectedTool: tool });
  };

  const handlePatchClick = (index: number) => {
    const patch = gameState.patches[index];
    
    if (gameState.selectedTool === 'fertilizer' && !patch.fertilized && gameState.fertilizerCount > 0) {
      fertilizePatch(index);
    } else if (gameState.selectedTool === 'plant' && patch.fertilized && !patch.planted) {
      plantMuna(index);
    } else if (gameState.selectedTool === 'fertilizer' && gameState.fertilizerCount === 0) {
      showMessage('No tienes más fertilizante disponible', 'warning');
    } else if (gameState.selectedTool === 'plant' && !patch.fertilized) {
      showMessage('Primero debes fertilizar esta parcela', 'warning');
    } else if (gameState.selectedTool === 'plant' && patch.planted) {
      showMessage('Ya hay una planta de muña aquí', 'warning');
    }
  };

  const fertilizePatch = (index: number) => {
    const newPatches = [...gameState.patches];
    newPatches[index].fertilized = true;
    
    onUpdateState({
      patches: newPatches,
      fertilizedCount: gameState.fertilizedCount + 1,
      fertilizerCount: gameState.fertilizerCount - 1
    });
    
    showMessage('¡Parcela fertilizada correctamente!', 'success');
  };

  const plantMuna = (index: number) => {
    const newPatches = [...gameState.patches];
    newPatches[index].planted = true;
    
    onUpdateState({
      patches: newPatches,
      plantedCount: gameState.plantedCount + 1
    });
    
    showMessage('¡Muña plantada exitosamente!', 'success');
  };

  const showMessage = (text: string, type: string) => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  // Show progress messages
  useEffect(() => {
    if (gameState.plantedCount === 8) {
      showMessage('¡Excelente progreso! Solo necesitas 4 plantas más para completar el nivel.', 'success');
    } else if (gameState.plantedCount === 10) {
      showMessage('¡Casi terminas! Solo 2 plantas más.', 'success');
    }
  }, [gameState.plantedCount]);

  const handleReset = () => {
    const resetPatches = Array(24).fill(null).map(() => ({ fertilized: false, planted: false }));
    onUpdateState({
      patches: resetPatches,
      fertilizedCount: 0,
      plantedCount: 0,
      fertilizerCount: 15,
      selectedTool: null
    });
    showMessage('Juego reiniciado', 'success');
  };

  const progress = (gameState.plantedCount / 12) * 100;

  return (
    <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold text-peru-green mb-2">🌿 Guardián de la Muña</h1>
        <p className="text-xl text-mountain-blue">Cultiva y protege la muña en las alturas de Arequipa</p>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-white rounded-lg p-4 text-center border-2 border-mountain-blue">
          <h3 className="font-bold text-peru-green">Parcelas Fertilizadas</h3>
          <p className="text-2xl font-bold text-mountain-blue">{gameState.fertilizedCount}</p>
        </div>
        <div className="bg-white rounded-lg p-4 text-center border-2 border-mountain-blue">
          <h3 className="font-bold text-peru-green">Plantas de Muña</h3>
          <p className="text-2xl font-bold text-mountain-blue">{gameState.plantedCount}</p>
        </div>
        <div className="bg-white rounded-lg p-4 text-center border-2 border-mountain-blue">
          <h3 className="font-bold text-peru-green">Fertilizante</h3>
          <p className="text-2xl font-bold text-mountain-blue">{gameState.fertilizerCount}</p>
        </div>
      </div>
      
      {/* Progress */}
      <div className="w-full bg-gray-200 rounded-full h-5 mb-6 relative">
        <div 
          className="bg-gradient-to-r from-plant-green to-lime-500 h-5 rounded-full transition-all duration-500 flex items-center justify-center"
          style={{ width: `${progress}%` }}
        >
          {progress > 20 && (
            <span className="text-white text-sm font-bold">
              {gameState.plantedCount}/12 plantas
            </span>
          )}
        </div>
        {progress <= 20 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-gray-600 text-sm font-bold">
              {gameState.plantedCount}/12 plantas
            </span>
          </div>
        )}
      </div>
      
      {/* Controls */}
      <div className="flex justify-center gap-4 mb-6">
        <button 
          className={`bg-gradient-to-r from-yellow-400 to-orange-400 text-peru-brown px-6 py-3 rounded-full font-bold hover:shadow-lg transition-all ${
            gameState.selectedTool === 'fertilizer' ? 'scale-110 shadow-lg' : ''
          }`}
          onClick={() => selectTool('fertilizer')}
        >
          💧 Fertilizar
        </button>
        <button 
          className={`bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transition-all border-2 border-green-800 shadow-md ${
            gameState.selectedTool === 'plant' ? 'scale-110 shadow-xl ring-4 ring-green-300' : 'hover:scale-105'
          }`}
          onClick={() => selectTool('plant')}
        >
          🌱 Plantar Muña
        </button>
        <button 
          className="bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-3 rounded-full font-bold hover:shadow-lg transition-all"
          onClick={handleReset}
        >
          🔄 Reiniciar
        </button>
      </div>
      
      {/* Message */}
      {message && (
        <div className={`text-center p-4 rounded-lg mb-4 font-bold ${
          message.type === 'success' 
            ? 'bg-green-100 text-green-800 border border-green-300'
            : message.type === 'warning'
            ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
            : 'bg-red-100 text-red-800 border border-red-300'
        }`}>
          {message.text}
        </div>
      )}
      
      {/* Soil Grid */}
      <div className="bg-gradient-to-r from-peru-brown to-yellow-800 rounded-2xl p-6 mb-6 min-h-[300px] border-4 border-amber-800">
        <div className="grid grid-cols-6 gap-2 h-full">
          {gameState.patches.map((patch: any, index: number) => (
            <div
              key={index}
              className={`border-2 border-amber-800 rounded-lg p-3 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg flex flex-col items-center justify-center min-h-[80px] relative ${
                patch.planted 
                  ? 'bg-plant-green' 
                  : patch.fertilized 
                  ? 'bg-yellow-800' 
                  : 'bg-peru-brown'
              }`}
              onClick={() => handlePatchClick(index)}
            >
              {patch.planted && <span className="text-3xl grow-animation">🌿</span>}
              {patch.fertilized && !patch.planted && <span className="text-2xl sparkle-animation">💧</span>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Education */}
      <div className="bg-blue-50 rounded-xl p-6 border-2 border-mountain-blue">
        <h3 className="text-xl font-bold text-peru-green mb-4">🎓 Aprende sobre la Muña</h3>
        <ul className="text-mountain-blue space-y-2">
          <li><strong>Habitat:</strong> Crece en altitudes de 2,500 a 4,000 metros en Caylloma y Castilla, Arequipa</li>
          <li><strong>Propiedades:</strong> Planta aromática con propiedades medicinales y digestivas</li>
          <li><strong>Cultivo:</strong> Necesita suelo bien drenado y fertilizado con materia orgánica</li>
          <li><strong>Importancia:</strong> Parte fundamental de la medicina tradicional andina</li>
          <li><strong>Conservación:</strong> Vulnerable por la recolección excesiva y cambio climático</li>
        </ul>
      </div>
      
      {/* Navigation */}
      <div className="flex justify-between mt-6">
        <button 
          className="bg-mountain-blue text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
          onClick={onBack}
        >
          🏠 Menú
        </button>
        {gameState.completed && (
          <button 
            className="bg-action-red text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors"
            onClick={onComplete}
          >
            ➡️ Siguiente Nivel
          </button>
        )}
      </div>
    </div>
  );
}
