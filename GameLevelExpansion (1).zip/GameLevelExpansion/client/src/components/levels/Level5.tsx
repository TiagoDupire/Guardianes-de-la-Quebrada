import { useState, useEffect } from 'react';
import { Question } from '@/types/game';

interface Level5Props {
  gameState: any;
  onComplete: () => void;
  onBack: () => void;
  onUpdateState: (updates: any) => void;
  onReset: () => void;
}

const questions: Question[] = [
  {
    question: "¿Cuál es el nombre científico de la Muña y a qué altitud crece principalmente?",
    options: [
      "Minthostachys mollis - Entre 2,700 y 3,400 m.s.n.m.",
      "Senecio graveolens - Entre 3,500 y 4,000 m.s.n.m.",
      "Zea mays - Entre 1,000 y 2,000 m.s.n.m."
    ],
    correct: 0
  },
  {
    question: "¿Cuál es el principal componente antioxidante del maíz morado y qué beneficios aporta?",
    options: [
      "Flavonoides - Ayuda a la digestión",
      "Antocianinas - Protege contra el cáncer y enfermedades cardiovasculares",
      "Vitamina C - Fortalece el sistema inmunológico"
    ],
    correct: 1
  },
  {
    question: "¿Para qué se utiliza tradicionalmente la chachacoma en las comunidades andinas?",
    options: [
      "Para curar heridas y cortes",
      "Para combatir el mal de altura y problemas digestivos",
      "Para teñir textiles de colores naturales"
    ],
    correct: 1
  },
  {
    question: "¿Cuáles son los principales beneficios medicinales de la Muña?",
    options: [
      "Solo alivia problemas digestivos",
      "Únicamente trata enfermedades de la piel",
      "Alivia enfermedades respiratorias, problemas digestivos y tiene propiedades antisépticas"
    ],
    correct: 2
  },
  {
    question: "¿Qué propiedades especiales han descubierto los científicos en la chachacoma?",
    options: [
      "Propiedades anticancerígenas y antimicrobianas",
      "Solo propiedades nutritivas",
      "Únicamente propiedades aromáticas"
    ],
    correct: 0
  }
];

export default function Level5({ gameState, onComplete, onBack, onUpdateState }: Level5Props) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<{ text: string; type: string } | null>(null);

  useEffect(() => {
    if (gameState.currentQuestion >= questions.length && !gameState.gameFinished) {
      const finalScore = gameState.score * 20; // Convert to percentage
      onUpdateState({ 
        gameFinished: true, 
        completed: true, 
        score: finalScore 
      });
    }
  }, [gameState.currentQuestion, gameState.gameFinished, gameState.score]);

  const selectOption = (optionIndex: number) => {
    if (gameState.answered) return;
    
    setSelectedOption(optionIndex);
    const currentQuestion = questions[gameState.currentQuestion];
    const isCorrect = optionIndex === currentQuestion.correct;
    
    if (isCorrect) {
      onUpdateState({ score: gameState.score + 1 });
      setFeedback({
        text: '¡Correcto! Excelente conocimiento sobre las plantas peruanas.',
        type: 'success'
      });
    } else {
      setFeedback({
        text: `Incorrecto. La respuesta correcta era: ${currentQuestion.options[currentQuestion.correct]}`,
        type: 'error'
      });
    }
    
    onUpdateState({ answered: true });
  };

  const nextQuestion = () => {
    if (gameState.currentQuestion < questions.length - 1) {
      onUpdateState({ 
        currentQuestion: gameState.currentQuestion + 1,
        answered: false
      });
      setSelectedOption(null);
      setFeedback(null);
    } else {
      endGame();
    }
  };

  const endGame = () => {
    onUpdateState({ gameFinished: true });
    setTimeout(() => onComplete(), 2000);
  };

  const restartQuiz = () => {
    onUpdateState({
      currentQuestion: 0,
      score: 0,
      answered: false,
      gameFinished: false
    });
    setSelectedOption(null);
    setFeedback(null);
  };

  if (gameState.gameFinished) {
    return (
      <div className="bg-gradient-to-br from-peru-green via-plant-green to-lime-400 p-6">
        {/* Header */}
        <div className="bg-gradient-to-br from-peru-brown to-yellow-800 text-white p-6 rounded-2xl mb-8 text-center shadow-lg">
          <div className="text-4xl mb-4">🌿</div>
          <h1 className="text-4xl font-bold mb-2 drop-shadow-lg">
            ¡Juego Completado!
          </h1>
          <p className="text-xl opacity-90">Has terminado tu aprendizaje sobre plantas medicinales del Perú</p>
        </div>

        {/* Score */}
        <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 border-2 border-yellow-600 p-5 rounded-2xl mb-5 text-xl text-yellow-900 text-center shadow font-bold">
          <strong>Puntuación Final: {gameState.score}/5 correctas</strong>
        </div>

        {/* Final Message */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-700 text-white p-8 rounded-2xl text-2xl text-center shadow-xl mb-6 border-2 border-purple-800">
          <div className="text-4xl mb-4">🎉</div>
          <strong className="text-white text-3xl drop-shadow-lg">¡Gracias por jugar!</strong>
          <p className="mt-4 text-white font-bold text-xl drop-shadow-lg">Has completado el juego sobre las plantas medicinales del Perú</p>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-5 mb-6">
          <button 
            className="bg-gray-600 text-white px-8 py-3 rounded-full hover:bg-gray-700 transition-colors font-bold"
            onClick={restartQuiz}
          >
            🔄 Reiniciar Quiz
          </button>
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button 
            className="bg-mountain-blue text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
            onClick={onBack}
          >
            🏠 Menú
          </button>
          <button 
            className="bg-action-red text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors"
            onClick={onComplete}
          >
            🎉 Completar Juego
          </button>
        </div>
      </div>
    );
  }

  const currentQuestion = questions[gameState.currentQuestion];

  return (
    <div className="bg-gradient-to-br from-peru-green via-plant-green to-lime-400 p-6">
      {/* Header */}
      <div className="bg-gradient-to-br from-peru-brown to-yellow-800 text-white p-6 rounded-2xl mb-8 text-center shadow-lg">
        <div className="text-4xl mb-4">🌿</div>
        <h1 className="text-4xl font-bold mb-2 drop-shadow-lg">
          Lo que aprendimos sobre las plantas del Perú
        </h1>
        <p className="text-xl text-white font-bold drop-shadow-lg">¡Descubre el poder curativo de nuestras plantas ancestrales!</p>
      </div>
      
      {/* Question */}
      <div className="bg-gray-50 p-6 rounded-2xl mb-5 border-4 border-plant-green shadow-lg">
        <div className="bg-plant-green text-white px-5 py-3 rounded-full text-xl font-bold mb-4 inline-block">
          Pregunta {gameState.currentQuestion + 1} de {questions.length}
        </div>
        
        <div className="text-2xl text-gray-800 mb-5 leading-relaxed">
          {currentQuestion.question}
        </div>
        
        <div className="space-y-4 mb-5">
          {currentQuestion.options.map((option, index) => {
            let className = "bg-white border-2 border-gray-300 p-4 rounded-xl cursor-pointer transition-all duration-300 hover:bg-green-50 hover:border-plant-green hover:-translate-y-1 hover:shadow-lg text-lg text-gray-800";
            
            if (gameState.answered) {
              if (index === currentQuestion.correct) {
                className = "bg-green-500 text-white border-2 border-green-600 p-4 rounded-xl text-lg font-bold";
              } else if (index === selectedOption) {
                className = "bg-red-500 text-white border-2 border-red-600 p-4 rounded-xl text-lg font-bold";
              } else {
                className = "bg-gray-200 text-gray-600 border-2 border-gray-300 p-4 rounded-xl text-lg";
              }
            }
            
            return (
              <div
                key={index}
                className={className}
                onClick={() => selectOption(index)}
              >
                {option}
              </div>
            );
          })}
        </div>
        
        {feedback && (
          <div className={`p-4 rounded-lg font-bold ${
            feedback.type === 'success' 
              ? 'bg-green-100 text-green-800 border border-green-300'
              : 'bg-red-100 text-red-800 border border-red-300'
          }`}>
            {feedback.text}
          </div>
        )}
      </div>
      
      {/* Controls */}
      <div className="flex justify-center gap-5 mb-6">
        {gameState.answered && (
          <button 
            className="bg-plant-green text-white px-8 py-3 rounded-full hover:bg-green-700 transition-colors font-bold"
            onClick={nextQuestion}
          >
            {gameState.currentQuestion < questions.length - 1 ? 'Siguiente' : 'Finalizar'}
          </button>
        )}
      </div>
      
      {/* Score */}
      <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 border-2 border-yellow-600 p-5 rounded-2xl mb-5 text-xl text-yellow-900 text-center shadow font-bold">
        <strong>Puntuación: {gameState.score}/{questions.length}</strong>
      </div>
      
      {/* Navigation */}
      <div className="flex justify-between">
        <button 
          className="bg-mountain-blue text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
          onClick={onBack}
        >
          🏠 Menú
        </button>
      </div>
    </div>
  );
}
