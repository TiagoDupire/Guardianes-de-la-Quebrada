import { useState, useEffect } from 'react';

interface Level4Props {
  gameState: any;
  onComplete: () => void;
  onBack: () => void;
  onUpdateState: (updates: any) => void;
  onReset: () => void;
}

const educationalFacts = [
  "📚 ¿Sabías que el maíz morado tiene antioxidantes que protegen tu corazón?",
  "📚 El pigmento morado del maíz tiene antocianinas, antioxidantes naturales que ayudan al sistema circulatorio.",
  "📚 El Kculli es una variedad ancestral cultivada en el valle del Colca desde tiempos preincaicos.",
  "📚 Las antocianinas del maíz morado pueden ayudar a reducir la inflamación en el cuerpo.",
  "📚 El maíz morado del Colca es rico en fibra y ayuda a la digestión."
];

export default function Level4({ gameState, onComplete, onBack, onUpdateState }: Level4Props) {
  const [message, setMessage] = useState<{ text: string; type: string } | null>(null);
  const [educationText, setEducationText] = useState<string>('');
  const [showEducation, setShowEducation] = useState(false);
  const [cornItems, setCornItems] = useState<Array<{ id: number; isLarge: boolean }>>([]);

  useEffect(() => {
    if (gameState.day >= 7 && gameState.health > 60 && !gameState.harvestStarted) {
      startHarvest();
    }
  }, [gameState.day, gameState.health, gameState.harvestStarted]);

  const waterPlant = () => {
    if (gameState.day - gameState.lastWatered < 1) {
      showMessage('¡Ya regaste hoy! Espera al siguiente día.', 'warning');
      return;
    }
    
    if (gameState.water > 70) {
      showMessage('¡Cuidado! Demasiada agua puede pudrir las raíces.', 'warning');
      return;
    }
    
    onUpdateState({
      water: Math.min(100, gameState.water + 30),
      lastWatered: gameState.day
    });
    
    showMessage('¡Planta regada correctamente! (+30 agua)', 'success');
  };

  const fertilizePlant = () => {
    if (gameState.day - gameState.lastFertilized < 2) {
      const daysLeft = 2 - (gameState.day - gameState.lastFertilized);
      showMessage(`¡Espera ${daysLeft} día(s) más antes de fertilizar!`, 'warning');
      return;
    }
    
    onUpdateState({
      nutrients: Math.min(100, gameState.nutrients + 35),
      lastFertilized: gameState.day
    });
    
    showMessage('¡Planta fertilizada correctamente! (+35 nutrientes)', 'success');
  };

  const nextDay = () => {
    const newDay = gameState.day + 1;
    const newWater = Math.max(0, gameState.water - 12);
    const newNutrients = Math.max(0, gameState.nutrients - 8);
    
    // Calculate health based on water and nutrients only
    const idealWater = newWater >= 30 && newWater <= 80;
    const idealNutrients = newNutrients >= 25;
    
    let newHealth = gameState.health;
    let healthMessage = '';
    
    if (idealWater && idealNutrients) {
      newHealth = Math.min(100, newHealth + 15);
      healthMessage = '¡La planta está creciendo saludablemente!';
      showMessage(healthMessage, 'success');
    } else {
      let issues = [];
      if (newWater < 30) issues.push('necesita agua');
      if (newNutrients < 25) issues.push('necesita fertilizante');
      
      newHealth = Math.max(0, newHealth - 8);
      healthMessage = `La planta ${issues.join(' y ')}`;
      showMessage(healthMessage, 'warning');
    }
    
    onUpdateState({
      day: newDay,
      water: newWater,
      nutrients: newNutrients,
      health: newHealth,
      gameOver: newHealth <= 0
    });
    
    // Show educational fact
    if (newDay % 2 === 0) {
      const fact = educationalFacts[Math.floor(Math.random() * educationalFacts.length)];
      setEducationText(fact);
      setShowEducation(true);
      setTimeout(() => setShowEducation(false), 5000);
    }
    
    // Game over check
    if (newHealth <= 0) {
      showMessage('¡La planta murió! Reinicia el nivel.', 'error');
    }
  };

  const startHarvest = () => {
    onUpdateState({ harvestStarted: true });
    
    // Create corn items
    const items = Array.from({ length: 16 }, (_, i) => ({
      id: i,
      isLarge: Math.random() < 0.3 // 30% chance of large corn
    }));
    setCornItems(items);
  };

  const harvestCorn = (id: number, isLarge: boolean) => {
    const points = isLarge ? 10 : 2;
    const newHarvestScore = gameState.harvestScore + points;
    
    onUpdateState({ harvestScore: newHarvestScore });
    
    showMessage(
      isLarge 
        ? '¡Excelente! Cosechaste maíz morado maduro!'
        : 'Cosechaste maíz joven, ¡sigue buscando los morados!',
      isLarge ? 'success' : 'warning'
    );
    
    setCornItems(prev => prev.filter(item => item.id !== id));
  };

  useEffect(() => {
    if (cornItems.length === 0 && gameState.harvestStarted && gameState.harvestScore > 0) {
      setTimeout(() => {
        onUpdateState({ completed: true, score: gameState.harvestScore });
        showMessage(`¡Felicidades! Cosechaste ${gameState.harvestScore} puntos de maíz morado.`, 'success');
        setTimeout(() => onComplete(), 2000);
      }, 1000);
    }
  }, [cornItems.length, gameState.harvestStarted, gameState.harvestScore]);

  const showMessage = (text: string, type: string) => {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  };

  const restartLevel = () => {
    onUpdateState({
      water: 50,
      sun: 80,
      nutrients: 60,
      health: 70,
      day: 1,
      lastWatered: 0,
      lastFertilized: 0,
      gameOver: false,
      harvestScore: 0,
      harvestStarted: false
    });
    setCornItems([]);
    setMessage(null);
  };

  const getPlantEmoji = () => {
    if (gameState.health > 80) return '🌽';
    if (gameState.health > 40) return '🌱';
    return '🌿';
  };

  const getPlantScale = () => {
    if (gameState.health > 80) return 'transform scale-110';
    return '';
  };

  return (
    <div className="bg-gradient-to-br from-peru-blue to-green-100 p-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold text-peru-green mb-2">🌽 Kculli Game</h1>
        <p className="text-xl text-peru-brown font-italic">Cultiva Maíz Morado del Valle del Colca - Arequipa</p>
      </div>

      {/* Progress and Goal */}
      <div className="bg-gradient-to-r from-purple-100 to-yellow-100 p-6 rounded-xl mb-6 border-2 border-purple-300">
        <h3 className="text-xl font-bold text-center text-purple-800 mb-4">🎯 Objetivo: Cultivar hasta el día 7 y cosechar</h3>
        <div className="w-full bg-purple-200 rounded-full h-6 mb-4 relative">
          <div 
            className="bg-gradient-to-r from-purple-500 to-purple-600 h-6 rounded-full transition-all duration-500 flex items-center justify-center"
            style={{ width: `${Math.min(100, (gameState.day / 7) * 100)}%` }}
          >
            {gameState.day > 0 && (
              <span className="text-white text-sm font-bold">
                Día {gameState.day}/7
              </span>
            )}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
            <h4 className="font-bold text-blue-800 mb-2">💧 Consejos de Riego:</h4>
            <ul className="text-blue-700 space-y-1">
              <li>• Riega cuando el agua esté por debajo de 30</li>
              <li>• No riegues si está arriba de 70 (se pudre)</li>
              <li>• Solo puedes regar una vez por día</li>
            </ul>
          </div>
          <div className="bg-green-50 p-3 rounded-lg border border-green-200">
            <h4 className="font-bold text-green-800 mb-2">🌾 Consejos de Fertilización:</h4>
            <ul className="text-green-700 space-y-1">
              <li>• Fertiliza cuando los nutrientes estén bajo 25</li>
              <li>• Espera 2 días entre fertilizaciones</li>
              <li>• Los nutrientes bajan lentamente cada día</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Enhanced Stats with Visual Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className={`rounded-xl p-4 text-center border-2 transition-all ${
          gameState.water >= 30 ? 'bg-blue-100 border-blue-400' : 'bg-red-100 border-red-400 animate-pulse'
        }`}>
          <div className="flex items-center justify-center mb-2">
            <span className="text-2xl font-bold">{gameState.water}</span>
            <span className="ml-2">{gameState.water < 30 ? '⚠️' : '💧'}</span>
          </div>
          <div className="text-sm font-semibold">Agua</div>
          <div className="text-xs mt-1">
            {gameState.water < 30 ? 'Necesita riego' : 'Bien hidratada'}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className={`h-2 rounded-full transition-all ${gameState.water >= 30 ? 'bg-blue-500' : 'bg-red-500'}`}
              style={{ width: `${gameState.water}%` }}
            ></div>
          </div>
        </div>
        
        <div className={`rounded-xl p-4 text-center border-2 transition-all ${
          gameState.nutrients >= 25 ? 'bg-green-100 border-green-400' : 'bg-red-100 border-red-400 animate-pulse'
        }`}>
          <div className="flex items-center justify-center mb-2">
            <span className="text-2xl font-bold">{gameState.nutrients}</span>
            <span className="ml-2">{gameState.nutrients < 25 ? '⚠️' : '🌾'}</span>
          </div>
          <div className="text-sm font-semibold">Nutrientes</div>
          <div className="text-xs mt-1">
            {gameState.nutrients < 25 ? 'Necesita fertilizante' : 'Bien nutrida'}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className={`h-2 rounded-full transition-all ${gameState.nutrients >= 25 ? 'bg-green-500' : 'bg-red-500'}`}
              style={{ width: `${gameState.nutrients}%` }}
            ></div>
          </div>
        </div>
        
        <div className={`rounded-xl p-4 text-center border-2 transition-all ${
          gameState.health > 50 ? 'bg-pink-100 border-pink-400' : 'bg-gray-100 border-gray-400'
        }`}>
          <div className="flex items-center justify-center mb-2">
            <span className="text-2xl font-bold">{gameState.health}</span>
            <span className="ml-2">❤️</span>
          </div>
          <div className="text-sm font-semibold">Salud</div>
          <div className="text-xs mt-1">
            {gameState.health > 80 ? 'Excelente' : gameState.health > 50 ? 'Buena' : 'Débil'}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
            <div 
              className={`h-2 rounded-full transition-all ${
                gameState.health > 80 ? 'bg-green-500' : 
                gameState.health > 50 ? 'bg-yellow-500' : 'bg-red-500'
              }`}
              style={{ width: `${gameState.health}%` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-purple-100 border-purple-400 rounded-xl p-4 text-center border-2">
          <div className="flex items-center justify-center mb-2">
            <span className="text-2xl font-bold">{gameState.day}</span>
            <span className="ml-2">📅</span>
          </div>
          <div className="text-sm font-semibold">Día</div>
          <div className="text-xs mt-1">
            {gameState.day < 7 ? `${7 - gameState.day} días para cosecha` : 'Listo para cosechar'}
          </div>
        </div>
      </div>
      
      {/* Plant */}
      <div className="bg-gradient-to-br from-peru-brown to-yellow-800 rounded-3xl p-8 mb-6 min-h-[200px] flex justify-center items-end relative">
        <div className={`text-6xl transition-all duration-500 filter drop-shadow-lg ${getPlantScale()} ${gameState.health <= 40 ? 'grayscale' : ''}`}>
          {getPlantEmoji()}
        </div>
      </div>
      
      {/* Actions */}
      {!gameState.harvestStarted && !gameState.gameOver && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <button 
            className={`p-4 rounded-xl font-bold transition-all ${
              gameState.day - gameState.lastWatered >= 1 && gameState.water <= 70
                ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white hover:shadow-lg hover:-translate-y-1'
                : 'bg-gray-300 text-gray-600 cursor-not-allowed'
            }`}
            onClick={waterPlant}
            disabled={gameState.day - gameState.lastWatered < 1 || gameState.water > 70}
          >
            💧 Regar<br/>
            <span className="text-xs">
              {gameState.day - gameState.lastWatered < 1 ? 'Ya regado hoy' : 
               gameState.water > 70 ? 'Demasiada agua' : 'Disponible'}
            </span>
          </button>
          <button 
            className={`p-4 rounded-xl font-bold transition-all ${
              gameState.day - gameState.lastFertilized >= 2
                ? 'bg-gradient-to-br from-green-500 to-green-600 text-white hover:shadow-lg hover:-translate-y-1'
                : 'bg-gray-300 text-gray-600 cursor-not-allowed'
            }`}
            onClick={fertilizePlant}
            disabled={gameState.day - gameState.lastFertilized < 2}
          >
            🌾 Fertilizar<br/>
            <span className="text-xs">
              {gameState.day - gameState.lastFertilized < 2 
                ? `Espera ${2 - (gameState.day - gameState.lastFertilized)} día(s)` 
                : 'Disponible'}
            </span>
          </button>
          <button 
            className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-xl font-bold hover:shadow-lg transition-all hover:-translate-y-1"
            onClick={nextDay}
          >
            🌅 Siguiente Día<br/>
            <span className="text-xs">Avanzar tiempo</span>
          </button>
          <button 
            className="bg-gradient-to-br from-red-500 to-red-600 text-white p-4 rounded-xl font-bold hover:shadow-lg transition-all hover:-translate-y-1"
            onClick={restartLevel}
          >
            🔄 Reiniciar<br/>
            <span className="text-xs">Empezar de nuevo</span>
          </button>
        </div>
      )}
      
      {/* Message */}
      {message && (
        <div className={`rounded-xl p-5 mb-4 font-bold text-lg shadow ${
          message.type === 'success' 
            ? 'bg-green-100 text-green-800 border border-green-300'
            : message.type === 'warning'
            ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
            : 'bg-red-100 text-red-800 border border-red-300'
        }`}>
          {message.text}
        </div>
      )}
      
      {/* Education */}
      {showEducation && (
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-5 mb-4 border-2 border-mountain-blue shadow">
          <div className="text-lg font-bold text-mountain-blue mb-2">📚 Dato Educativo</div>
          <div className="text-mountain-blue">{educationText}</div>
        </div>
      )}
      
      {/* Harvest Game */}
      {gameState.harvestStarted && (
        <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl p-5 mb-4 border-2 border-purple-500">
          <h3 className="text-xl font-bold text-purple-700 mb-4 text-center">🌽 ¡Hora de Cosechar!</h3>
          <p className="text-purple-600 text-center mb-4">Haz clic en las mazorcas grandes (moradas) para cosechar</p>
          
          <div className="grid grid-cols-4 gap-2 mb-4">
            {cornItems.map((corn) => (
              <div
                key={corn.id}
                className={`corn-item p-4 rounded-lg cursor-pointer transition-all duration-300 hover:scale-110 hover:shadow-lg text-2xl text-center ${
                  corn.isLarge 
                    ? 'bg-gradient-to-br from-purple-500 to-purple-700 text-white' 
                    : 'bg-gradient-to-br from-yellow-400 to-yellow-600'
                }`}
                onClick={() => harvestCorn(corn.id, corn.isLarge)}
              >
                {corn.isLarge ? '🌽' : '🌾'}
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <div className="text-lg font-bold text-purple-700">
              Puntuación de Cosecha: {gameState.harvestScore}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-5 mt-2">
              <div 
                className="bg-gradient-to-r from-purple-500 to-purple-600 h-5 rounded-full transition-all duration-500"
                style={{ width: `${Math.min(100, (gameState.harvestScore / 100) * 100)}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}
      
      {/* Game Over */}
      {gameState.gameOver && (
        <div className="bg-gradient-to-br from-purple-800 to-purple-900 text-white rounded-3xl p-8 text-center text-xl shadow-xl">
          <div className="text-4xl mb-4">🎉</div>
          <div className="text-2xl font-bold mb-4">¡Felicidades!</div>
          <div className="mb-6">Has completado el cultivo de Kculli</div>
          <button 
            className="bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-xl font-bold hover:shadow-lg transition-all"
            onClick={restartLevel}
          >
            🔄 Reiniciar Nivel
          </button>
        </div>
      )}
      
      {/* Navigation */}
      <div className="flex justify-between">
        <button 
          className="bg-mountain-blue text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
          onClick={onBack}
        >
          🏠 Menú
        </button>
        {gameState.completed && (
          <button 
            className="bg-action-red text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors"
            onClick={onComplete}
          >
            ➡️ Siguiente Nivel
          </button>
        )}
      </div>
    </div>
  );
}
