import { useState, useEffect } from 'react';

interface Level3Props {
  gameState: any;
  onComplete: () => void;
  onBack: () => void;
  onUpdateState: (updates: any) => void;
  onReset: () => void;
}

export default function Level3({ gameState, onComplete, onBack, onUpdateState }: Level3Props) {
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => {
    if (gameState.infusionesCreadas >= 3 && !gameState.completed) {
      onUpdateState({ completed: true, score: gameState.puntuacion });
      addMessage('🎉 ¡Felicidades! Has completado el nivel de Chachacoma. Nivel 4 desbloqueado.', 'success');
      setTimeout(() => onComplete(), 2000);
    }
  }, [gameState.infusionesCreadas, gameState.completed]);

  // Add helpful progress messages
  useEffect(() => {
    if (gameState.infusionesCreadas === 1) {
      addMessage('🌿 ¡Primera infusión creada! Necesitas 2 más para completar el nivel.', 'success');
    } else if (gameState.infusionesCreadas === 2) {
      addMessage('🌿 ¡Segunda infusión lista! Solo una más para terminar el nivel.', 'success');
    }
  }, [gameState.infusionesCreadas]);

  useEffect(() => {
    if (gameState.diasSaludable === 3) {
      addMessage('💪 ¡Muy bien! La planta está saludable. Mantén el cuidado 2 días más.', 'success');
    } else if (gameState.diasSaludable === 4) {
      addMessage('🌟 ¡Excelente! Un día más de salud y crearás una infusión.', 'success');
    }
  }, [gameState.diasSaludable]);

  const addMessage = (text: string, type: string) => {
    const newMessage = { text, type, day: gameState.dia };
    const updatedMessages = [newMessage, ...gameState.mensajes.slice(0, 4)];
    onUpdateState({ mensajes: updatedMessages });
  };

  const waterPlant = () => {
    const newAgua = Math.min(100, gameState.agua + 25);
    onUpdateState({ agua: newAgua });
    addMessage('💧 Regaste la chachacoma', 'success');
  };

  const fertilizePlant = () => {
    const newNutrientes = Math.min(100, gameState.nutrientes + 20);
    onUpdateState({ nutrientes: newNutrientes });
    addMessage('🌱 Fertilizaste la chachacoma', 'success');
  };

  const exposeSun = () => {
    const newSol = Math.min(100, gameState.sol + 15);
    onUpdateState({ sol: newSol });
    addMessage('☀️ Expusiste la planta al sol', 'success');
  };

  const resetLevel = () => {
    onUpdateState({
      agua: 45,
      sol: 80,
      nutrientes: 55,
      salud: 100,
      temperatura: 'fría',
      dia: 1,
      diasSaludable: 0,
      infusionesCreadas: 0,
      puntuacion: 0,
      mensajes: [],
      gameOver: false,
      completed: false
    });
    addMessage('🔄 Nivel reiniciado. ¡Cuida bien la chachacoma!', 'success');
  };

  const advanceDay = () => {
    // Natural degradation
    let newAgua = Math.max(0, gameState.agua - 8);
    const newSol = Math.max(0, gameState.sol - 5);
    const newNutrientes = Math.max(0, gameState.nutrientes - 3);
    const newDia = gameState.dia + 1;
    
    // Random temperature
    const newTemperatura = Math.random() < 0.2 ? 'cálida' : 'fría';
    
    // Hot climate affects water levels instead of health
    if (newTemperatura === 'cálida') {
      newAgua = Math.max(0, newAgua - 10); // Extra water loss on hot days
      addMessage('☀️ Día cálido: la planta necesita más agua', 'warning');
    }
    
    onUpdateState({
      agua: newAgua,
      sol: newSol,
      nutrientes: newNutrientes,
      dia: newDia,
      temperatura: newTemperatura
    });
    
    calculateHealth(newAgua, newSol, newNutrientes, newTemperatura, newDia);
  };

  const calculateHealth = (agua: number, sol: number, nutrientes: number, temperatura: string, dia: number) => {
    let nuevaSalud = gameState.salud;
    
    // Health impacts
    if (agua > 70) {
      nuevaSalud -= 15;
      addMessage('⚠️ El exceso de agua está pudriendo las raíces', 'warning');
    }
    
    if (sol < 40) {
      nuevaSalud -= 10;
      addMessage('🌥️ Le falta sol para crecer bien', 'warning');
    }
    
    // Ideal conditions bonus
    if (agua >= 30 && agua <= 60 && sol >= 60 && sol <= 100 && nutrientes >= 40 && nutrientes <= 70) {
      nuevaSalud += 5;
      addMessage('🌿 La chachacoma está en condiciones ideales', 'success');
    }
    
    // Health limits
    nuevaSalud = Math.max(0, Math.min(100, nuevaSalud));
    
    // Count healthy days
    let newDiasSaludable = gameState.diasSaludable;
    if (nuevaSalud > 80) {
      newDiasSaludable += 1;
    } else {
      newDiasSaludable = 0;
    }
    
    // Reward for maintaining high health
    let newInfusiones = gameState.infusionesCreadas;
    let newPuntuacion = gameState.puntuacion;
    
    if (newDiasSaludable >= 5) {
      newInfusiones += 1;
      newPuntuacion += 50;
      newDiasSaludable = 0;
      addMessage('🌿 ¡Tu chachacoma está lista para hacer infusión medicinal!', 'success');
    }
    
    onUpdateState({
      salud: nuevaSalud,
      diasSaludable: newDiasSaludable,
      infusionesCreadas: newInfusiones,
      puntuacion: newPuntuacion,
      gameOver: nuevaSalud <= 0
    });
    
    if (nuevaSalud <= 0) {
      addMessage('💀 La chachacoma murió. ¡Reinicia el nivel!', 'error');
    }
  };

  const getStatusIcon = (valor: number, min: number, max: number) => {
    if (valor >= min && valor <= max) return '✅';
    if (valor < min) return '❌';
    return '⚠️';
  };

  const getBarColor = (valor: number, min: number, max: number) => {
    if (valor >= min && valor <= max) return 'bg-green-500';
    if (valor < min) return 'bg-red-500';
    return 'bg-yellow-500';
  };

  return (
    <div className="bg-gradient-to-br from-green-50 to-blue-50 p-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h1 className="text-4xl font-bold text-peru-green mb-2">🌿 Cuidando la Chachacoma</h1>
        <p className="text-xl text-gray-600">Planta medicinal andina de Arequipa</p>
        <button 
          className="mt-2 bg-mountain-blue text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
          onClick={() => setShowInfo(!showInfo)}
        >
          📚 Información de la Planta
        </button>
      </div>
      
      {/* Plant Info Modal */}
      {showInfo && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl max-w-md mx-4">
            <h3 className="text-xl font-bold text-peru-green mb-4">🌿 Chachacoma</h3>
            <ul className="space-y-2 text-sm">
              <li><strong>Nombre científico:</strong> Senecio graveolens</li>
              <li><strong>Hábitat:</strong> Zonas altoandinas de 3,500-4,500 m</li>
              <li><strong>Propiedades:</strong> Mal de altura, digestivo</li>
              <li><strong>Uso:</strong> Infusiones medicinales</li>
            </ul>
            <button 
              className="mt-4 bg-mountain-blue text-white px-4 py-2 rounded"
              onClick={() => setShowInfo(false)}
            >
              Cerrar
            </button>
          </div>
        </div>
      )}
      
      {/* Progress Indicator */}
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-6 rounded-xl mb-6 border-2 border-purple-300">
        <h3 className="text-xl font-bold text-center text-purple-800 mb-4">🎯 Objetivo del Nivel</h3>
        <div className="text-center mb-4">
          <span className="text-lg font-semibold text-purple-700">
            Crear 3 infusiones medicinales manteniendo la planta saludable
          </span>
        </div>
        <div className="w-full bg-purple-200 rounded-full h-6 mb-4 relative">
          <div 
            className="bg-gradient-to-r from-purple-500 to-purple-600 h-6 rounded-full transition-all duration-500 flex items-center justify-center"
            style={{ width: `${Math.min(100, (gameState.infusionesCreadas / 3) * 100)}%` }}
          >
            {gameState.infusionesCreadas > 0 && (
              <span className="text-white text-sm font-bold">
                {gameState.infusionesCreadas}/3 infusiones
              </span>
            )}
          </div>
          {gameState.infusionesCreadas === 0 && (
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-purple-700 text-sm font-bold">
                0/3 infusiones
              </span>
            </div>
          )}
        </div>
        <p className="text-sm text-purple-600 text-center">
          💡 Para crear infusiones, mantén la planta saludable (&gt;80%) por 5 días consecutivos
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded-lg text-center shadow">
          <div className="text-2xl font-bold text-mountain-blue">Día {gameState.dia}</div>
          <div className="text-sm text-gray-600">Tiempo</div>
        </div>
        <div className="bg-white p-4 rounded-lg text-center shadow">
          <div className="text-2xl font-bold text-plant-green">{gameState.puntuacion}</div>
          <div className="text-sm text-gray-600">Puntos</div>
        </div>
        <div className="bg-white p-4 rounded-lg text-center shadow">
          <div className="text-2xl font-bold text-purple-600">{gameState.infusionesCreadas}/3</div>
          <div className="text-sm text-gray-600">Infusiones</div>
        </div>
        <div className="bg-white p-4 rounded-lg text-center shadow">
          <div className="text-2xl">{gameState.temperatura === 'fría' ? '❄️' : '☀️'}</div>
          <div className="text-sm text-gray-600">Clima</div>
        </div>
      </div>
      
      {/* Plant Status and Actions */}
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-bold text-peru-green mb-4">🌱 Estado de la Chachacoma</h3>
          
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-2">
                  💧 Agua: {gameState.agua}% {getStatusIcon(gameState.agua, 30, 60)}
                </span>
                <span className="text-sm text-gray-600">Ideal: 30-60%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all duration-500 ${getBarColor(gameState.agua, 30, 60)}`}
                  style={{ width: `${gameState.agua}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-2">
                  ☀️ Sol: {gameState.sol}% {getStatusIcon(gameState.sol, 60, 100)}
                </span>
                <span className="text-sm text-gray-600">Ideal: 60-100%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all duration-500 ${getBarColor(gameState.sol, 60, 100)}`}
                  style={{ width: `${gameState.sol}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-2">
                  🌱 Nutrientes: {gameState.nutrientes}% {getStatusIcon(gameState.nutrientes, 40, 70)}
                </span>
                <span className="text-sm text-gray-600">Ideal: 40-70%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all duration-500 ${getBarColor(gameState.nutrientes, 40, 70)}`}
                  style={{ width: `${gameState.nutrientes}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="flex items-center gap-2">❤️ Salud: {gameState.salud}%</span>
                <span className="text-sm text-gray-600">Días saludables: {gameState.diasSaludable}/5</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full transition-all duration-500 ${gameState.salud > 50 ? 'bg-green-500' : 'bg-red-500'}`}
                  style={{ width: `${gameState.salud}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Actions */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-bold text-peru-green mb-4">🎮 Acciones Diarias</h3>
          
          <div className="space-y-4">
            <button 
              className="w-full bg-blue-500 text-white p-4 rounded-lg hover:bg-blue-600 transition-colors font-bold"
              onClick={waterPlant}
              disabled={gameState.gameOver}
            >
              💧 Regar (Agua +25)
            </button>
            <button 
              className="w-full bg-green-500 text-white p-4 rounded-lg hover:bg-green-600 transition-colors font-bold"
              onClick={fertilizePlant}
              disabled={gameState.gameOver}
            >
              🌱 Fertilizar (Nutrientes +20)
            </button>
            <button 
              className="w-full bg-yellow-500 text-white p-4 rounded-lg hover:bg-yellow-600 transition-colors font-bold"
              onClick={exposeSun}
              disabled={gameState.gameOver}
            >
              ☀️ Exponer al Sol (Sol +15)
            </button>
            <button 
              className="w-full bg-purple-500 text-white p-4 rounded-lg hover:bg-purple-600 transition-colors font-bold"
              onClick={advanceDay}
              disabled={gameState.gameOver}
            >
              ⏰ Avanzar Día
            </button>
            <button 
              className="w-full bg-red-500 text-white p-4 rounded-lg hover:bg-red-600 transition-colors font-bold"
              onClick={resetLevel}
            >
              🔄 Reiniciar Nivel
            </button>
          </div>
        </div>
      </div>
      
      {/* Messages */}
      <div className="bg-white rounded-lg p-4 mb-4 shadow min-h-[100px]">
        <h4 className="font-bold text-peru-green mb-2">📝 Registro de Eventos</h4>
        <div className="space-y-1 text-sm max-h-20 overflow-y-auto">
          {gameState.mensajes.map((mensaje: any, index: number) => (
            <div 
              key={index}
              className={`text-sm ${
                mensaje.type === 'success' ? 'text-green-600' : 
                mensaje.type === 'warning' ? 'text-yellow-600' : 'text-red-600'
              }`}
            >
              Día {mensaje.day}: {mensaje.text}
            </div>
          ))}
        </div>
      </div>
      
      {/* Navigation */}
      <div className="flex justify-between">
        <button 
          className="bg-mountain-blue text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition-colors"
          onClick={onBack}
        >
          🏠 Menú
        </button>
        {gameState.completed && (
          <button 
            className="bg-action-red text-white px-6 py-3 rounded-lg hover:bg-red-600 transition-colors"
            onClick={onComplete}
          >
            ➡️ Siguiente Nivel
          </button>
        )}
      </div>
    </div>
  );
}
