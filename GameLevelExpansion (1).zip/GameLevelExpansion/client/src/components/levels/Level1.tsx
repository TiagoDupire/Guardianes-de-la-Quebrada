import { useState, useEffect } from 'react';
import { Contaminant } from '@/types/game';

interface Level1Props {
  gameState: any;
  onComplete: () => void;
  onBack: () => void;
  onUpdateState: (updates: any) => void;
  onReset: () => void;
}

const initialContaminants: Contaminant[] = [
  { type: 'trash', x: 15, y: 25, emoji: '🗑️' },
  { type: 'fire', x: 65, y: 35, emoji: '🔥' },
  { type: 'oil', x: 30, y: 45, emoji: '🛢️' },
  { type: 'trash', x: 80, y: 20, emoji: '🗑️' },
  { type: 'fire', x: 25, y: 60, emoji: '🔥' },
  { type: 'oil', x: 70, y: 55, emoji: '🛢️' },
  { type: 'trash', x: 45, y: 30, emoji: '🗑️' },
  { type: 'fire', x: 85, y: 40, emoji: '🔥' },
  { type: 'oil', x: 10, y: 50, emoji: '🛢️' },
  { type: 'trash', x: 55, y: 65, emoji: '🗑️' }
];

export default function Level1({ gameState, onComplete, onBack, onUpdateState }: Level1Props) {
  const [contaminants, setContaminants] = useState<Contaminant[]>(initialContaminants);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number }>>([]);

  useEffect(() => {
    if (contaminants.length === 0 && !gameState.completed) {
      onUpdateState({ completed: true, score: 100, contaminantsRemaining: 0 });
      setTimeout(() => onComplete(), 1000);
    }
  }, [contaminants.length, gameState.completed]);

  const removeContaminant = (index: number, event: React.MouseEvent) => {
    const rect = (event.target as HTMLElement).getBoundingClientRect();
    
    // Create particle effect
    const newParticles = Array.from({ length: 5 }, (_, i) => ({
      id: Date.now() + i,
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2
    }));
    
    setParticles(prev => [...prev, ...newParticles]);
    
    // Remove particles after animation
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !newParticles.find(np => np.id === p.id)));
    }, 2000);
    
    // Remove contaminant
    const newContaminants = contaminants.filter((_, i) => i !== index);
    setContaminants(newContaminants);
    
    onUpdateState({ 
      contaminantsRemaining: newContaminants.length 
    });
  };

  const progress = ((10 - contaminants.length) / 10) * 100;

  return (
    <div className="bg-gradient-to-b from-peru-blue via-green-200 to-green-300 relative overflow-hidden" style={{ height: '600px' }}>
      {/* Game UI */}
      <div className="absolute top-4 left-4 bg-white/90 rounded-lg p-4 shadow-lg">
        <div className="text-lg font-bold text-peru-green">Nivel 1: Limpieza Ambiental</div>
        <div className="text-sm text-gray-600">Contaminantes: {contaminants.length}</div>
      </div>
      
      <div className="absolute top-4 right-4 w-48 h-8 bg-white/90 rounded-full overflow-hidden shadow-lg">
        <div 
          className="h-full bg-gradient-to-r from-plant-green to-lime-500 rounded-full transition-all duration-500 flex items-center justify-center text-white font-bold text-sm"
          style={{ width: `${progress}%` }}
        >
          {Math.round(progress)}%
        </div>
      </div>
      
      {/* Environment */}
      <div className="mountain absolute bottom-0 w-full h-48 bg-gradient-to-r from-peru-brown to-yellow-800" 
           style={{ clipPath: 'polygon(0 100%, 20% 40%, 40% 60%, 60% 30%, 80% 50%, 100% 100%)' }}>
      </div>
      
      <div className="river absolute bottom-0 left-1/2 transform -translate-x-1/2 w-36 h-24 bg-gradient-to-b from-mountain-blue to-blue-600 rounded-t-full border-4 border-slate-600">
      </div>
      
      {/* Trees and Natural Elements */}
      <div className="tree absolute bottom-12 left-16 w-8 h-16 bg-peru-brown rounded-sm">
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 bg-plant-green rounded-full"></div>
      </div>
      <div className="tree absolute bottom-12 right-20 w-8 h-16 bg-peru-brown rounded-sm">
        <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 w-12 h-12 bg-plant-green rounded-full"></div>
      </div>
      <div className="tree absolute bottom-16 left-1/3 w-6 h-12 bg-peru-brown rounded-sm">
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-10 h-10 bg-green-600 rounded-full"></div>
      </div>
      <div className="tree absolute bottom-16 right-1/3 w-6 h-12 bg-peru-brown rounded-sm">
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 w-10 h-10 bg-green-600 rounded-full"></div>
      </div>
      
      {/* Bushes */}
      <div className="absolute bottom-8 left-8 w-8 h-6 bg-green-500 rounded-full"></div>
      <div className="absolute bottom-10 left-28 w-6 h-4 bg-green-600 rounded-full"></div>
      <div className="absolute bottom-8 right-8 w-8 h-6 bg-green-500 rounded-full"></div>
      <div className="absolute bottom-10 right-28 w-6 h-4 bg-green-600 rounded-full"></div>
      <div className="absolute bottom-12 left-2/3 w-5 h-3 bg-green-400 rounded-full"></div>
      
      {/* Rocks */}
      <div className="absolute bottom-6 left-12 w-4 h-3 bg-gray-500 rounded-full"></div>
      <div className="absolute bottom-8 right-12 w-3 h-2 bg-gray-600 rounded-full"></div>
      <div className="absolute bottom-6 left-1/2 w-5 h-4 bg-gray-400 rounded-full transform -translate-x-1/2"></div>
      
      {/* Grass patches */}
      <div className="absolute bottom-4 left-6 w-3 h-8 bg-green-300 rounded-t-full transform rotate-12"></div>
      <div className="absolute bottom-4 left-10 w-2 h-6 bg-green-400 rounded-t-full transform -rotate-12"></div>
      <div className="absolute bottom-4 right-6 w-3 h-8 bg-green-300 rounded-t-full transform -rotate-12"></div>
      <div className="absolute bottom-4 right-10 w-2 h-6 bg-green-400 rounded-t-full transform rotate-12"></div>
      <div className="absolute bottom-5 left-1/4 w-2 h-7 bg-green-500 rounded-t-full"></div>
      <div className="absolute bottom-5 right-1/4 w-2 h-7 bg-green-500 rounded-t-full"></div>
      
      {/* Flowers */}
      <div className="absolute bottom-8 left-24 text-yellow-400 text-sm">🌼</div>
      <div className="absolute bottom-12 right-16 text-pink-400 text-sm">🌸</div>
      <div className="absolute bottom-6 left-3/4 text-purple-400 text-sm">🌺</div>
      
      {/* Clouds */}
      <div className="absolute top-8 left-12 w-16 h-8 bg-white rounded-full opacity-80"></div>
      <div className="absolute top-6 left-16 w-12 h-6 bg-white rounded-full opacity-80"></div>
      <div className="absolute top-12 right-20 w-20 h-10 bg-white rounded-full opacity-80"></div>
      <div className="absolute top-10 right-24 w-14 h-7 bg-white rounded-full opacity-80"></div>
      
      {/* Contaminants */}
      {contaminants.map((contaminant, index) => (
        <div
          key={index}
          className="absolute cursor-pointer transition-all duration-300 hover:scale-110 z-10 border-4 border-harvest-gold rounded-lg p-2 shadow-lg"
          style={{ left: `${contaminant.x}%`, top: `${contaminant.y}%` }}
          onClick={(e) => removeContaminant(index, e)}
        >
          <span className="text-4xl">{contaminant.emoji}</span>
        </div>
      ))}
      
      {/* Particles */}
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="absolute w-3 h-3 bg-harvest-gold rounded-full pointer-events-none animate-bounce"
          style={{ 
            left: particle.x, 
            top: particle.y,
            animation: 'float-away 2s ease-out forwards'
          }}
        />
      ))}
      
      {/* Instructions */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-white/80 rounded-lg p-3 text-center pulse-animation">
        <div className="text-peru-green font-semibold">
          ¡Haz clic en los contaminantes para limpiar el ambiente!
        </div>
      </div>
      
      {/* Navigation */}
      <button 
        className="nav-button absolute bottom-4 right-4 bg-mountain-blue text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
        onClick={onBack}
      >
        🏠 Menú
      </button>
    </div>
  );
}
