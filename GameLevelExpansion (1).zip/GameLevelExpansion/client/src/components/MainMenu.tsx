import { GameState } from '@/types/game';

interface MainMenuProps {
  gameState: GameState;
  onLevelSelect: (levelNum: number) => void;
  onResetGame: () => void;
}

export default function MainMenu({ gameState, onLevelSelect, onResetGame }: MainMenuProps) {
  const levels = [
    { id: 1, emoji: '🌍', title: 'Limpieza Ambiental', description: 'Protege el ecosistema de las plantas' },
    { id: 2, emoji: '🌿', title: 'Cultivo de Muña', description: 'Cultiva la planta aromática andina' },
    { id: 3, emoji: '🏔️', title: 'Cuidado de Chachacoma', description: 'Mantén saludable la planta de altura' },
    { id: 4, emoji: '🌽', title: 'Cultivo de Kculli', description: 'Cultiva maíz morado del Colca' },
    { id: 5, emoji: '🎓', title: 'Examen Final', description: 'Demuestra tus conocimientos' }
  ];

  const isLevelUnlocked = (levelId: number) => {
    return levelId === 1 || gameState.levelsCompleted.includes(levelId - 1);
  };

  const isLevelCompleted = (levelId: number) => {
    return gameState.levelsCompleted.includes(levelId);
  };

  const getLevelStatus = (levelId: number) => {
    if (isLevelCompleted(levelId)) {
      return { text: '⭐ Completado', className: 'bg-harvest-gold text-white' };
    } else if (isLevelUnlocked(levelId)) {
      return { text: '✓ Disponible', className: 'bg-green-500 text-white' };
    } else {
      return { text: '🔒 Bloqueado', className: 'bg-gray-400 text-white' };
    }
  };

  return (
    <div className="p-8 text-center bg-gradient-to-br from-peru-blue to-green-100">
      <div className="mb-8">
        <h1 className="text-5xl font-bold text-peru-green mb-4 drop-shadow-lg">
          🌿 Plantas Medicinales del Perú
        </h1>
        <p className="text-xl text-mountain-blue mb-2">
          Descubre el poder curativo de nuestras plantas ancestrales
        </p>
        <p className="text-lg text-gray-600 mb-6 italic">
          Por : Tiago Dupire
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-4xl mx-auto">
        {levels.map((level) => {
          const status = getLevelStatus(level.id);
          const unlocked = isLevelUnlocked(level.id);
          
          return (
            <div
              key={level.id}
              className={`level-card bg-white rounded-xl p-6 shadow-lg border-2 transition-all duration-300 ${
                unlocked 
                  ? 'border-plant-green hover:shadow-xl cursor-pointer hover:-translate-y-1' 
                  : 'border-gray-300 opacity-60 cursor-not-allowed'
              }`}
              onClick={() => unlocked && onLevelSelect(level.id)}
            >
              <div className="text-4xl mb-4">{level.emoji}</div>
              <div className={`text-2xl font-bold mb-2 ${unlocked ? 'text-plant-green' : 'text-gray-500'}`}>
                Nivel {level.id}
              </div>
              <div className={`text-lg font-semibold mb-2 ${unlocked ? 'text-gray-800' : 'text-gray-600'}`}>
                {level.title}
              </div>
              <div className={`text-sm mb-4 ${unlocked ? 'text-gray-600' : 'text-gray-500'}`}>
                {level.description}
              </div>
              <div className="mt-4 flex justify-center">
                <span className={`level-status px-3 py-1 rounded-full text-sm ${status.className}`}>
                  {status.text}
                </span>
              </div>
            </div>
          );
        })}
      </div>
      
      <div className="mt-8 bg-white/80 rounded-xl p-6">
        <h3 className="text-xl font-bold text-peru-green mb-4">Progreso Global</h3>
        <div className="w-full bg-gray-200 rounded-full h-4 mb-4">
          <div 
            className="progress-fill bg-gradient-to-r from-plant-green to-lime-500 h-4 rounded-full transition-all duration-500" 
            style={{ width: `${(gameState.plantsLearned / 4) * 100}%` }}
          ></div>
        </div>
        <div className="flex justify-between text-sm text-gray-600 mb-4">
          <span>Plantas aprendidas: <span className="font-bold">{gameState.plantsLearned}</span>/4</span>
          <span>Puntuación total: <span className="font-bold">{gameState.totalScore}</span></span>
        </div>
        
        {/* Global Reset Button */}
        {gameState.plantsLearned > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-300">
            <button 
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold transition-colors duration-300 shadow-lg hover:shadow-xl"
              onClick={() => {
                if (confirm('¿Estás seguro de que quieres reiniciar todo el juego? Se perderá todo el progreso.')) {
                  onResetGame();
                }
              }}
            >
              🔄 Reiniciar Juego Completo
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
