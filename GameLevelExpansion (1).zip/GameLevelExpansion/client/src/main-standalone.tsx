import { createRoot } from "react-dom/client";
import App from "./App-standalone";
import "./index.css";

// Override console.error to suppress React Query errors in standalone mode
const originalError = console.error;
console.error = (...args) => {
  const message = args[0];
  if (typeof message === 'string' && (
    message.includes('fetch') || 
    message.includes('network') || 
    message.includes('api') ||
    message.includes('TanStack')
  )) {
    // Suppress fetch/API related errors in standalone mode
    return;
  }
  originalError.apply(console, args);
};

createRoot(document.getElementById("root")!).render(<App />);